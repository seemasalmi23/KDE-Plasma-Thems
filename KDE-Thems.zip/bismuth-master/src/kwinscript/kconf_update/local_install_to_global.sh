#!/usr/bin/env sh

# SPDX-FileCopyrightText: 2021 Mikhail Zolotukhin <mail@gikari.com>
# SPDX-License-Identifier: MIT

# Remove local installation of the script.
# It will be substituted with the global installation.
rm -r ~/.local/share/kwin/scripts/bismuth
