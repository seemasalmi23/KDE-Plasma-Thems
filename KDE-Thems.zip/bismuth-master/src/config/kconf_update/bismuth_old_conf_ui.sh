#!/usr/bin/env sh

# SPDX-FileCopyrightText: 2021 Mikhail Zolotukhin <mail@gikari.com>
# SPDX-License-Identifier: MIT

# Remove symlink for legacy config ui
rm ~/.local/share/kservices5/bismuth.desktop
