<!--
  SPDX-FileCopyrightText: 2021-2022 Mikhail Zolotukhin <mail@gikari.com>
  SPDX-License-Identifier: MIT
-->

# 🗺️ Roadmap

Here are some notable features, that are planned in the future:

1. Plasma Applet, that lets you interact with the window placement.
2. More freedom in the automatic window placement.
3. Window decoration, that is aware of the window tiling.
