<!--
  SPDX-FileCopyrightText: 2022 Mikhail Zolotukhin <mail@gikari.com>
  SPDX-License-Identifier: MIT
-->

# 📔 Documentation

This is a table of contents of the documentation.

- [Project Vision (Broad description of the project future)](VISION.md)
- [Project Roadmap (More concrete description of the project future)](ROADMAP.md)
- [Tweaks that could be useful for the end-user](TWEAKS.md)
